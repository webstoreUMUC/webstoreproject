<!DOCTYPE html>
<html>

<!-- the head section -->
<head>
    <title>Gen3Market</title>
</head>

<!-- the body section -->
<body>
<header><h1>Gen3Market</h1></header>

<main>
    <h2 class="top">Error</h2>
    <p><?php echo $error; ?></p>
</main>

<footer>
    <p>&copy; <?php echo date("Y"); ?> Gen3Market</p>
</footer>
</body>
</html>