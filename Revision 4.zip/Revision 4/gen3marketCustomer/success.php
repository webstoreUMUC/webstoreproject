<?php
/**

 */
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../styles/main.css">

    <title>Order Complete</title>
</head>
<body>
<main> 
    <header>Gen3Market</header>
    <div id="logo">
        <img id="fb" src="../images/gen3marketlogo1.png">
    </div>
    <h1>Success</h1>
<p>Thank you for using gen3market. Your order is being processed.</p>
</main>
<footer>
    <br><p>&copy; <?php echo date("Y"); ?>Gen3Market</p>
</footer>
</body>
</html>
